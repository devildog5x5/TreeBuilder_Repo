Readme for Tree_Bldr.exe

Written by Robert Foster

Surname Field
Context Field
Home directory Field
Directory creation Field and batch file creation functionality.
Changed a few names to more properly identify some fields.

This is a work in progress. 
To use this tool:
Your screen resolution must be 1024 x 768 or it will cut off the right side (VB issue).
Make your selections, the UserID will start at the selected number and incriment to the selected number (you must 
select a value on both "Enter biginning number" field and "Enter ending number" field or the program will bail 
out on you. 
The default values reflect actuals and are almost always OK to use, just make sure that 
you have created the object first. If you are using the default contex of ,ou=engineering,o=novell you will
need to have first created the Organizaion "novell" and the Organizational Unit "engineering".

Exception: "Enter volume/path for user home directory"
The location and syntax is important on this here is the default value:
cn=SRVR1_VOL1,o=novell#0#\users\
replace the SRVR1 with your server name ie;ST22 and replace the vol1 with your volume name ie; sys, 
replace user with your subdirectory from the root of that volume.

Note: You may have a volume a long distance down the tree so get the LDAP context right. 
ie; cn=ST22_VOL1,ou=6deep,ou=5deep,ou=4deep,ou=3deep,ou=st22,o=novel
It amy also be advantageous to create a volume object higher up the tree heiracy that points 
to the original volume object via nwadmin.exe.

Click on the "Write LDIF file", it shouldn't take long to create the file then move the file to
the following directory on the web server:
SYS:\Novonyx\suitespot\userdb\ldap\tools\
Go to the NetWare Web Manager --> Global Settings -->  Select LDAP Directory server. It is recomended 
at this point that you stop and restart your web server using nswebdn.ncf and nswebup.ncf (this will stop
and restart the web server and the web manager).
Then select users and groups --> Import.
That should be it if you get containment errors etc. make sure the objects in the LDIF file all exist and that you 
did not alter the default syntax.


Click on the "Write batch file" copy the file to the subdirectory you want the user folders to be created in.
From the command line execute make_dir.bat. It will create the user directory, the public_html directory and 
an index.html file pubulated with the username.

Switch the directory service back to NDS and you should be good to go.

Depending on how healthy and how large your tree is you should be able to access user home directories within a few 
minutes, but generally you will not be able to access them immediatley and you may need to restart the web server
again.

One issue that I ran into was that the SYS:\Novonyx\suitespot\userdb\DBSWITCH.CONF did not get put back to
the defaults so I could not see my PUBLIC_HTML directories. Make sure it looks like the following:

 
default ldap://st22.provo.novell.com:389/o%3Dnovell
default:RIGHTSMODE Directory
default:PASSEXREDIRFILE \novonyx\suitespot\docs\ndsredirect.html
default:PUBLIC perl
default:PUBLIC servlet
default:PUBLIC netbasic
default:PUBLIC sp
default:PUBLIC nsn
default:PUBLIC se
default:PUBLIC /novonyx/suitespot/docs
default:PUBLIC /novonyx/suitespot/ns-icons
default:PUBLIC public_html
default:PUBLIC /novonyx/suitespot/lcgi-bin
default:PUBLIC /novonyx/suitespot/plugins/search/ui/icons
default:PUBLIC /cgi-bin

If is is different than this (other than the server name) 
look for a file in the same location J:\Novonyx\suitespot\userdb\dbswitch.org and copy the contents of it into 
the DBSWITCH.CONF file.

Information of note:
At the time of this writting a tool was needed by System Test to create users with home 
directories, in large numbers and none had the functionality needed.

Bulkload (NDS Bulk loaderand, used with BT.EXE) and ICE (Import/Conversion/Export available via a 
ConsoleOne.exe wizard) did not support "homeDirectory:" as a control. As a result, they were not viable.

Uimport.exe stopped working with the release of NW 5.1 (my understanding is that they no longer wanted to 
support uimport because the afore mentioned tools were going to be a complete solution and oimport.exe that 
had been available from consulting was difficult to get at.

I also felt that we needed a tool that would be more versatile and easier to use.

You may still use this utility to generate most of what you need to do with ice, but you may need to strip
lines out of the file manually, if there is  something specific that you would like and I still have the source,
I would be happy to add it in.

Use Web Manger to import your ldif, you will need to change your web server to LDAP database 
to get Import Export to show up in Users and Groups menu. When it is available, you can use ICE.NLM to 
import your ldif, here is a sample of how you may use ICE.EXE or ICE.NLM  from the command line. Or use 
the wizard available in ConsoleOne.exe when it becomes available.
See sys:ice.log for additional command line options.
ice -S LDIF -f ST22_vol1:\ldif_f~1.txt -D LDAP -s ST22